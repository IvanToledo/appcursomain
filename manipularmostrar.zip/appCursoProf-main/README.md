#Tela Principal

![image](https://github.com/silvioflorentino/appCurso/assets/28194425/c1c9a30e-083f-4e8e-af97-ff3e45810833)

#Cadastro de Categoria
![image](https://github.com/silvioflorentino/appCurso/assets/28194425/63de773c-2f06-4d11-b83f-8bd3e17b46b6)

#Cadastro de Aula
![image](https://github.com/silvioflorentino/appCurso/assets/28194425/b2b91afa-ecd5-4a0f-bcd4-ca149f22cfb3)




